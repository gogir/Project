              iKey Components Version 4.2.0.4
                         README.TXT
              Copyright � 2011 SafeNet, Inc.
                     All Rights Reserved.
----------------------------------------------------------------------------                            

Thank you for choosing iKey Components from SafeNet! 
iKey Components contains the drivers and libraries used for SafeNet's
iKey Security Tokens.

This README file provides information on product installation and 
uninstallation, new features, last-minute news and where to go  
for more information or to report problems.

-----------------------------
 Table of Contents
-----------------------------

1.0 Installing iKey Components
    1.1 Compatibility
    1.2 Installation
    1.3 Netscape PKCS#11 Registration	
2.0 What's New in This Release?
    2.1 Problems Fixed in This Release
3.0 Late-Breaking Information
4.0 Known Problems
5.0 Acknowledgements
6.0 Reporting Problems

----------------------------------------------------------
 1.0 INSTALLING IKEY COMPONENTS
----------------------------------------------------------

-----------------------------
 1.1 Compatibility
-----------------------------

IMPORTANT! Please be sure to read this section completely BEFORE 
you run the iKey Components setup program, to be sure you are aware of any 
installation issues that may pertain to your system and environment.

 1. A Windows-based installation program is provided to 
    make iKey Components installation quick and easy.
    The installation program runs only on the following operating
    systems:

    	- Windows XP SP2, SP3 (32-bit, 64-bit)
	- Windows Server 2003 SP2 (32-bit, 64-bit) 
	- Windows Server 2003 R2 (32-bit, 64-bit)�
	- Windows Vista SP2 (32-bit, 64-bit) 
	- Windows 7, 7 SP1 (32-bit, 64-bit)
	- Windows Server 2008 SP2 (32-bit, 64-bit) 
	- Windows Server 2008 SP1 R2 (64-bit) 

    All systems require a functional USB controller to be installed prior
    to installation of iKey Components.

 2. On Toshiba Model T440 CDX laptops, iKey Security Tokens will not 
    be recognized. This is due to an incompatibility with the USB 
    controller used in the iKey Security Tokens. Currently, there is no 
    known workaround for this issue.

 3. iKey 2000 SDK/Authentication Solution Software (for 32-bit OS only)

    - When upgrading iKey Components on a system with the iKey 2000 SDK 
      or iKey 2000 Authentication Solution software installed, you must 
      restart your system upon completion of iKey Components installation. 
      This is required for the CIP service to see any new readers that may 
      have been created during iKey Components installation.

    - Under Windows XP, the "Start CIP on Boot" option must be disabled for 
      version 4.5 or version 4.6 of iKey 2000 SDK or iKey 2000 Authentication
      Solution software. If you already have the iKey 2000 SDK or iKey 2000 
      Authentication Solution v4.5 or v4.6 software installed, perform the 
      following steps to disable the "Start CIP on Boot" option:

	1. Open Control Panel.
	2. Select Switch to classic view.
	3. Open the Administrative Tools folder.
	4. Open the Services control panel applet.
	5. Select DkeyServ.
	6. For StartType, select Disabled.
	7. Restart your system.

      If you have not yet installed the iKey 2000 SDK or iKey 2000 
      Authentication v4.5 or v4.6 software, clear the "Start CIP on Boot" 
      option when performing the installation.

    - On all platforms, if a newer version of iKey Components is installed,
      and you install the iKey 2000 SDK or iKey 2000 Authentication Solution
      software, the operating system may not be able to find the appropriate
      device driver upon installation of an iKey Security Token. In this case, 
      you must rerun the iKey Components installation to repair the system.


 4.   When upgrading the iKey Driver from version 2.6 through 3.3 and above, all iKey 
      Security Tokens must be removed PRIOR to installation. This prevents
      you from being logged off during the driver upgrade if you are
      using an iKey Security Token for Smart Card logon.

      When upgrading the iKey Driver from version 3.3, you may be prompted
      by the system to restart your computer. Please click NO in ALL
      system restart message boxes until iKey Components installation is 
      complete. Failure to do so may cause iKey Components installation to 
      fail. If this occurs, rerun the setup program to repair the 
      installation.

      When upgrading the iKey Driver from version 2.6 through 3.3, error 
      messages may exist in the System Event Log after installation. These 
      error messages indicate that the installation could not create a 
      unique reader name. This is by design and has no effect on the iKey 
      Components installation.

 5. If you are planning to upgrade your operating system, uninstall iKey 
    Components and the iKey Driver BEFORE you perform the system upgrade. 
    After you have upgraded your system, you can then re-install iKey 
    Components.

 6. For supported windows platforms,installation of a iKey Security Token
    must be performed per-USB port,per-USB hub.  

-----------------------------
 1.2 Installation
-----------------------------

The following instructions assume you are installing the iKey software 
using a CD, and  that you are installing from CD-ROM drive D. If a drive 
other than drive D is used, substitute D: with the appropriate drive letter. 
(If installing from the Internet,  double-click the file you downloaded to 
start the installation process.)

 - Insert the CD into the CD-ROM drive.

 - If CD auto run is set, the installation should start. If not, from the 
   Start menu, select Run. The Run dialog box appears. 
   Type D:\IKEYALL.EXE at the Open prompt and click OK.
       
 - Follow the on-screen instructions to complete the installation. 
     
 - You can access this readme file from the SafeNet iKey Components program
   group. 

-----------------------------
 1.3 Netscape PKCS#11 Registration
-----------------------------

For versions 7.x and above of Netscape, the iKey Components installer will 
automatically register the iKey Cryptoki (PKCS#11) library for use under 
Netscape. If for some reason this process does not work with your current 
version of Netscape, you can register the iKey Cryptoki library manually 
with the provided HTML file. This HTML file is located in the following
location:

<ProgramFiles>\SafeNet\iKey Components\Register_iKey_PKCS11_Netscape.html

Where <ProgramFiles> is the location of the Program Files folder on your 
system.

To register the iKey Cryptoki library with Netscape, perform these steps:

	1. Open Netscape.
	2. From the File menu, select Open File.
	3. Navigate to the following folder:

        <ProgramFiles>\SafeNet\iKey Components

	4. Select the Register_iKey_PKCS11_Netscape.html file.
	5. Close all instances of Netscape. 
	6. The registration process is now complete.


----------------------------------------------------------
 2.0 WHAT'S NEW IN THIS RELEASE?
----------------------------------------------------------
The following features are new in this release:

 - Support for MS CAPI and PKCS#11 API's on 64 bit platform and all applications utilizing
   the MS CAPI and PKCS#11 API's to access and store information on the iKey 1000

 - Porting of PKCS#11 API�s and iKey API based sample application (CKSample, TKEdit, iKeyEdit, iKey Token    Utility) on 64 bit platform.

 - Porting of iKey PCSC API�s based sample application (SSP) on 64 bit platform.

 - A new vendor-defined extension, R_ImportP12ToToken has been added in
   PKCS#11 library to support PFX/P12 file import functionality.

 - For supported Windows os, iKey Components can be 
   installed on 32 and 64 bit machines. iKeyALL.exe is now a single installer, 
   that detects the platform whether 32-bit or 64-bit, and installs 64-bit
   iKeyDriver on 64-bit and 32-bit iKeyDriver on 32-bit systems.

   The iKeyDriver is installed at its default location on both 32-bit and 64-bit
   systems.
	i.e        <system drive>\Program Files\SafeNet\iKeyDrvr

   And the other iKeyALL components will get installed at location

	<system drive>Program Files\SafeNet\iKey Components          Folder on 32-bit and 64-bit systems.


 - For supported windows platforms, iKey Components can be installed on a clean
   system with a iKey Security Token already attached.
   And on a clean system, a system reboot is no longer required to complete
   iKey Components installation.

 - iKey Components installation can now repair the current installation,
   if corrupted. To repair your system, simply rerun the iKey Components 
   setup program.

 - For supported windows platforms, the iKey Components now includes an 
   automatic certificate registration (ACR) service that automatically 
   registers upon token insertion any certificates on an iKey. 
   These certificates are also unregistered from the system 
   upon token removal. This feature requires that the iKey Driver be 
   configured for PC/SC support.

 - For supported windows platforms,the iKey Components now includes an 
   automatic certificate expiration warning notification service. 
   (This service requires the automatic certificate 
   registration [ACR] service to also be installed and running.) This service 
   warns the user when any of the certificates stored on an iKey 1000 are 
   about to expire. This feature requires the iKey Driver to be configured 
   for PC/SC support.

 - The iKey Token Utility (formerly called the iKey Certificate Manager) 
   contains additional support for Administrative functions. Refer to the 
   iKey 1000 Series Developer's Guide for information about enabling these 
   administrative functions.

 - The iKey PKCS#11 (Cryptoki) library can now be registered with version 6.x 
   of Netscape.

 - Vendor-defined extensions to the PKCS#11 library have been added to 
   support new functionality that is not available in the PKCS#11 standard.

 - The certificate password retry counter is a new feature in the PKCS#11 
   library that allows you to control the number of times the user can 
   attempt to correctly enter their certificate password to access PKI data 
   on the iKey.

 - The CRYPT_USER_PROTECTED flag is now supported in the CSP. It prevents 
   the user from unintentionally overwriting an existing key pair. By default, 
   this option is disabled.

   When a key pair is generated with the CRYPT_USER_PROTECTED flag enabled, 
   the SafeNet CSP will display a dialog box notifying the user when an 
   attempt to overwrite that key pair with a new key pair occurs. 

 - The SafeNet CSP now provides an extension for converting a non-CAPI 
   certificate into a format that can be recognized by MSCAPI. 

   Non-CAPI certificates stored on the iKey token can't be recognized by 
   MSCAPI-enabled applications such as Microsoft Outlook or the ACR Service. 
   In order for MSCAPI applications to recognize a certificate, it must 
   first be converted.

 - Online Help is now available for all Token Utility functions, and may be
   accessed from the Help menu. To view online Help, you must be running 
   supported platforms and have Internet Explorer 4.0 or later installed
   on your system. 

Please refer to the iKey 1000 SDK Release Notes for more detailed 
information on what is new in this version of iKey Components.

-----------------------------------
 2.1 Problems Fixed in This Release
-----------------------------------

v4.2.0.4 Release fixes:
- MKS CSR# 134908 - iKey1000SDK readme.txt update

v4.2.0.3 Release fixes:
- Sign CSP (k1pkrscp.dll) and PKCS#11 (k1pk112.dll) binaries from Microsoft.
- Updated iKeyAPIManual, iKeyDevGuide, iKey Authentication solution user and admin guides.

v4.2.0.2 Release fixes:
-Task# 130491: Win 2K8 32 as host in RDP in not working with Any 32/64 bit Windows OS.

v4.2.0.1 Release fixes:
-Task# 129441 - iKey 1000 SDK installer doesn�t copy samples executable files to �C:\Program 		 		Files\SafeNet\iKey 1000 SDK\Bin� folder
-Task# 129445 - In 64 bit machine, �SafeNet� Folder gets created in Program Files(x86) Folder too.
-Task# 129495 - iKey TU�s initialize prompt shows incomplete warning message.
-Task# 129496 - Error while removing certificate from iKey 1000
-Task# 130123 - Dialog for pin prompt is not in focus during VPN Connection

v4.2.0.0 Release fixes:
-Task# 122458: Support for MS CAPI on 64 bit platform and all applications utilizing the MS CAPI
               to access and store information on the iKey 1000.
-Task# 122463: Support for PKCS#11 API�s on 64 bit platform and all applications utilizing the
               PKCS#11APIs to access and store information on the iKey 1000.
-Task# 122465: Porting of PKCS#11 API�s and iKey API based sample application (CKSample, TKEdit,
               iKeyEdit, iKey Token Utility) on 64 bit platform.
-Task# 122466: Porting of iKey PCSC API�s based sample application (SSP) on 64 bit platform.
-Task# 122467: Distribution of 64 bit libraries through iKey 1000 SDK installer
-Task# 129187:  VPN support for iKey 1000 Win 7 64 Bit.

Version 4.1.2.1 Release Fixes:
- Task# 100219: PKCS #11 API C_GetMechanismList returns wrong list of
                supported mechanisms.

v4.1.1.3 Release fixes:
-Task# 94233: Documentation for ikey 1000 v4.1.1.2 requires updation.

v4.1.1.2 Release fixes:
-Task# 93011: Unable to initialize iKey 1000 when the default value of certificate password retry counter is changed.
-Task# 93051: Incorrect message gets displayed on selecting the CSP "SafeNet iKey 1000 RSA Cryptographic Service Provider" during 
Certificate Enrollment.
-Task# 93054: Token Selection dialog while certificate enrollment is not visible or in focus
-Task# 93187: Unable to sign Adobe pdf doc through PKCS #11 module
-Task# 93237: On XP 64, General Information displayed in iKey Token Utility is incomplete
-Task# 93260: Inconsistent behavior of iKey Driver un-installation in the case of 32-bit & 64-bit OSes.
-Task# 93271: Incorrect spelling and indentation found in the iKey 1000 SDK installer.
-Task# 93387: Copyright information needs to be updated for ikey 1000 SDK installer and ikey driver installer for 32-bit & 64-bit.
-Task# 93390: Manage option in the Certificates area on the User Tools tab in the Token Utility gives unexpected error in the case of non-CAPI 
certificates.
-Task# 93439: Incorrect description in the warning dialogue during the ikey driver 64-bit un-installation.
-Task# 93723: iKey 1000 conflict with Intel PRO/Set 1012632

v4.1.1.1 Release fixes:

-Task# 81960: P12TOTOKEN function like what is available with BSEC.
-Task# 60837: SSL authentication does not work with Firefox using iKey1000 with iKey 1000 SDK 4.0.0.8
-Task# 81962: Error in generating key pair on iKey1000 on a Windows Vista with iKey 1000 SDK ver 4.1.0.9 
	      using web enrollment.
-Task# 86149: Support for SDK and Driver on Windows Vista (32 and 64 bit), Windows Server 2008 (32 and 64 bit),
	      Windows Server 2008 R2 (64-bit) and Windows 7 (32 and 64 bit)
-Task# 83255: iKey 1000 SDK - MSCAPI related Problems.
-Task# 11830: UNINST command will install the iKey driver if it is not already on the system.
-Task# 88951: Creating File of size more than whatever memory left in a directory leads to memory corruption.
-Task# 84379: iKey driver version is not displayed in Add/Remove Programs when iKey driver has been upgraded from 
	      version 4.1.0.1006 to version 4.1.1
-Task# 89397: iKeyEditor crashes on Windows Vista x64.


v4.1.0.9 Release fixes: 
-Task# 42515: Unable to install ikey driver (v 4.1.0.0005 exe version) on 
	      Win 2000 Professional and Win 2000 server.


Version 4.1.0.8
- Task# 37148 - iKey Editor shows wrong iKey Driver version information in both 
		iKey1000 SDK 64 bit and iKey1000SDK 32 bit.

Version 4.1.0.7
- Task# 42291 Unable to enroll for/import certificate on ikey 1000.

Version 4.1.0.6
- Task# 42267 Unable to lanuch iKey Token Utility.

Version 4.1.0.5

- Task# 41835 uninstalling component installer on 64bit shows registry error.
- Task# 41830 Uninstalling component and driver installer will create an error on reboot.


Version 4.1.0.4

- Task#40938  iKeyAPI Manual incorrectly lists only 64 bit OSs in "Supported Platforms" lists.
- Task#41632 Create a Single installer for 32bit and 64bit iKey1000 SDK.
- Task#35119 iKey Token Utilities bottom row is not accessible (visible) under Korean Windows. 

Version 4.0.0.8
 - Task# 26702 Documentation contains reference to MAC Support and removed JAVA samples in iKey
	       1000 Series Developer Guide and iKey API Reference Guide
Version 4.0.0.7
 - Task# 25671 ReadMe needs to mention Netscape 7.x version as well for installation of crptoki library
 - Task# 25833 Windows logon is successful by entering wrong pin
 - Task# 25644 Not able to Uninstall iKey driver when installed with iKey1000SDK.

Version 4.0.0.6
 - Task# 25650 Rebranding for manufacturer's information and SSP sample information not appropriate
 - Task# 25671 ReadMe needs to mention Netscape 7.x version as well for installation of crptoki library
 - Task# 25833 Windows logon is successful by entering wrong pin

Version 4.0.0.5:

 - Task# 25831 After Unblocking a Token for Certificate Password not able to Logon to Windows with correct password.

Version 4.0.0.4:
 
 - Task# 25776 Unblocking the Certificate Password erases all the PKI area and the certificates present 
	       on the Token rendering token unusable for PKI operations.

Version 4.0.0.3:

 - Task# 25644 Not able to Uninstall iKey driver when installed with iKey1000SDK.
 - Task# 25676 Product version and Install Shield version needs revision throughout the documentation.
 - Task# 25677 Fonts and Orientation across the Admin Guide are inconsistent.
 - Task# 25671 ReadMe needs to mention Netscape 7.x version as well for installation of crptoki library.
 - Task# 25720 Uninstalling iKey Client Install after upgrade returns multiple errors.
 - Task# 25728 Logon Certificate option should display logon certificate for Win ViSTA as well in Token Utility.
 - Task# 25730 Old iKey bitmap exists in token selection dialog if multiple iKey Tokens exists.

 Version 4.0.0.2:

 - MKS Issue # 23239: iKey Bitmaps across Installer missing on Welcome Screen.
 - MKS Issue # 23611: Silent install is not working.
 - MKS Issue # 23252: Improper message displayed when token is already inserted
                      and then installation done
 - MKS Issue # 23565: Comand line Utilities(tkedit.exe) is not displaying correct
                      name and copyright information.
 - MKS Issue # 23429: iKey user pin expiry warning appears inappropriately when
                      the exceeding count has increased by one.
 - MKS Issue # 23501: Netscape registration page for ikey 1000 PKCS11 module
                      contains irrelevant text.
 - MKS Issue # 23500: Documentation related bugs.

 Version 3.4.9.9
 Included missing library iKeyCOM.dll

 Version 3.4.9.8
 Included iKey Driver v3.4.9.6

 Version 3.4.8.120
 Included iKey Driver v3.4.8.120

 Version 3.4.6.114
 - CR # 66128:   Registration of Cryptoki library with netscape 6.22 fails 
                 while using the command-line option 
                 "iKeyAll -a COMP_INSTALL_OPTS=1024". 
 - CR # 66148:   iKey1000 ver 2.2.0 build37 SDK installation NS 6.22 auto 
                 registration crashes and hangs installer. 
 - CR # 66156:   NOSTARTUP option fails to disable the token utility icon 
                 from the system tray. 
 - CR # 66324:   The shortcut for refresh (f5) in the token utility does not
                 refresh the status of the token utility. 
 - CR # 67547:   iKey Token utility reports the certificate import successful 
                 even if the PKI area is less then the required 
 - CR # 68080:   Client Download - uninstall may not be clean 
 - CR # 68205:   Installing ikeyall component using 
                 "ikeyall -a COMP_INSTALL_OPTS=4" aborts the installation 
                 process.
 - CR # 68683:   Modify the iKey certificate manager to default to "ALWAYS" 
                 for create and delete. 
 - CR # 69805:   ikeyall.exe 3.4.4.103 with parameters returns errors. 
 - CR # 69954:   Certificate for https access in iKey does not work, in 
                 system does work well.
 - CR # 69955:   Signed email issues.

 Version 3.4.5.108
 - CR # 68634:   Win2k: Uninstalling a unsigned driver causes blue screen
 - CR # 68588:   Win2K: Token not accessible if removed after suspend and 
                 reinserted during resume.
 - CR # 68201:   iKeyAll -a NOSTARTUP option does not install token utility 
                 if this option is used on an existing installation that 
                 does not include token utilities.

 Version 3.4.4.103
 - CR # 67848:    Windows XP: When HotFix Q328310 is installed, the iKey All 
                  installer causes an "Access is denied" error. 

 Version 3.4.0

 - CR # 62999:   iKey Certificate Manager fails to register certificates.
 - CR # 63175:   iKey Editor fails to return an error when an attempt is 
                 made to create a file under a directory that does not exist.
 - CR # 63509:   The Detail button for the Certificate Manager does not work.
 - CR # 63459:   iKey Certificate Manager can only display up to 29 
                 characters for the token name.
 - CR # 63510:   iKey Certificate Manager unregisters the wrong certificate.
 - CR # 63511:   iKey Certificate Manager may report error upon entering 
                 password for access to a .p12 file.
 - CR # 63512:   iKey Certificate Manager contains a typo on the Change 
                 Password screen, which incorrectly specifies the byte size
                 of a password.
 - CR # 63794:   iKey Certificate Manager does not display version 
                 information.
 - CR # 63926:   iKey Editor displays incorrect build information in the 
                 About box.
 - CR # 63938:   The v2.1.0 uninstall process does not remove all subkeys 
                 registered by the cryptographic service module.    
 - CR # 63990:   When no token is inserted, iKey Certificate Manager displays 
                 the prompt for inserting a token many times.
 - CR # 63991:   Typos exist in the iKey Certificate Manager.
 - CR # 63996:   iKey Certificate Manager handles '&' in token name 
                 incorrectly.
 - CR # 65035:   iKey Editor shows inconsistent PIN entry requirements 
                 between the Modify PIN dialog and the Confirmation dialog.
 - CR # 65225:   iKey Certificate Manager sometimes extracts the subject name 
                 information from a .p12 file incorrectly if the .p12 file 
                 contains both an end-user certificate and some intermediate
                 and/or trusted CA certificates.
 - CR # 65266:   C_CloseSession() returns CKR_OK even though the target 
                 session has yet to be opened.
 - CR # 65267:   With a key pair created with the CKA_Sign attribute set to 
                 False, the program succeeds in generating a digital 
                 signature.
 - CR # 65268:   A key pair created with the CKA_MODIFIABLE set to FALSE 
                 can still be changed with the C_SetAttributeValue function.
 - CR # 65311:   Calling object and token management functions without first 
                 initializing the Cryptoki library can cause an access 
                 violation.
 - CR # 65578:   CSP reports error 0x8009002 when performing VPN logon with
                 an iKey 1000 token and more than one token present in the 
                 system. 
 - CR # 66466:   While signing data with a RSA key that has its p < q, the 
                 C_Sign function in the Cryptoki library produces a 
                 different signature than the one from the openSSL library. 
 - CR # 66467:   Repeatedly calling C_Login/C_Logout causes memory leak.

iKey Driver Related Items

 Version 3.4.4.103
 - CR # 67992:   Windows 2000: When Hotfix 814033 is installed, the iKey 
                 driver installer fails.
  
 Version 3.4.0

 - CR # 65052:   ikey_GenRandom only returns maximum of 60 bytes of random 
                 data.
 - CR # 65065:   Recursive DeleteDir gives erroneous SUCCESS return.
 - CR # 66401:   With more than one token present, opening specific by 
                 serial number on the second token fails when the first one 
                 is in use.

For additional information on problems fixed, please see the iKey Driver 
ReadMe file, located under the Program Folders | SafeNet
| iKey Driver program group.

------------------------------------------------------
 3.0 LATE-BREAKING INFORMATION
------------------------------------------------------

Visit the SafeNet Inc. Web site at http://www.safenet-inc.com for the 
most up-to-date product information.

---------------------
 4.0 KNOWN PROBLEMS
---------------------

-  Installing v2.1.1 of iKey Components or the iKey 1000 SDK on a 
   system that has a newer version of iKey Driver installed, such as v3.4.0 
   or later, will fail.

   Workaround: Uninstall the new iKey driver, install iKey Components, and 
   then run the new iKey Driver installer to update the driver.

 - Under Windows 98 and Windows ME, if another vendor's smart card reader is
   already installed, iKey Components will be configured to run in non-PC/SC 
   mode. This avoids compatibility issues with some vendors' PC/SC smart 
   card reader drivers on these platforms.

 - Under Windows NT 4.0, installed applications and/or smart card
   readers that use the PC/SC environment may remove, upon uninstallation, 
   the SMCLIB.SYS file from the %SystemRoot%\System32\Drivers directory. 

  This file is required by the iKey Driver and can cause a system 
  trap if removed. As a result, SafeNet recommends you 
  do the following:
 
     1.  Uninstall iKey Components and the iKey Driver.
     2.  Uninstall the PC/SC applications and/or smart card reader drivers. 
     3.  Re-install iKey Components. 

  This will prevent an uninstall program from removing this file and 
  causing a system trap.

 - Under Windows XP, in the iKey 2000 SDK or iKey 2000 Authentication 
   Solution, the "Start CIP on Boot" option must be disabled. If you already
   have the iKey 2000 SDK or iKey 2000 Authentication Solution software 
   installed, and are upgrading iKey Components, perform the following steps 
   to disable the "Start CIP on Boot" option:

	1. Open Control Panel.
	2. Select Switch to classic view.
	3. Open the Administrative Tools folder.
	4. Open the Services control panel applet.
	5. Select DkeyServ.
	6. For StartType, select Disabled.
	7. Restart your system.

   If you have not yet installed the iKey 2000 SDK or iKey 2000 Authentication
   Solution software, clear the "Start CIP on Boot" option during 
   installation.

 - Under Windows NT 4.0, Windows 2000 and Windows XP, when uninstalling 
   version 2.6 through 3.3 of the iKey Driver, you must restart your system prior to 
   installing this version of the driver.

 - On all platforms, if a newer version of iKey Components is installed,
   and you install the iKey 2000 SDK or iKey 2000 Authentication Solution
   software, the operating system may not be able to find the appropriate
   device driver upon installation of an iKey Security Token. In this case, 
   you must rerun the iKey Components installation to repair the system.

Please refer to the iKey 1000 SDK Release Notes for more detailed 
information on known problems in this iKey Components release.

------------------------
 5.0 ACKNOWLEDGEMENTS
------------------------
This product includes software developed by the OpenSSL Project for 
use in the OpenSSL Toolkit (http://www.OpenSSL.org/)

-------------------------------------------------------
 6.0 REPORTING PROBLEMS
-------------------------------------------------------

If you find any problems while using the iKey 1000 Authentication Solution, please contact 
SafeNet Technical Support using any of the following methods:

===============================================
SafeNet, Inc. Customer Connection Center (C3)
http://c3.safenet-inc.com


Americas
=================================
Internet - http://www.safenet-inc.com/support/index.asp
E-mail - support@safenet-inc.com


United States
---------------------------------------------------------
Telephone - (800) 545-6608, (410) 931-7520


Europe
=================================
E-mail - support@safenet-inc.com

France
---------------------------------------------------------
Telephone - 0825 341000


Germany
---------------------------------------------------------
Telephone - 01803 (7246269)


United Kingdom
---------------------------------------------------------
Telephone -  +44 (0) 1276 608000, +1 410 931-7520 (Intl)


Pacific Rim
=================================
E-mail - support@safenet-inc.com


Australia and New Zealand
---------------------------------------------------------

Telephone - +1 410 931-7520(Intl)


China
---------------------------------------------------------

Telephone - (86) 10 8851 9191


India
---------------------------------------------------------

Telephone - +1 410 931-7520 (Intl)


Taiwan and Southeast Asia
---------------------------------------------------------

Telephone - (886) 2 27353736, +1 410 931-7520 (Intl)


OTHER COUNTRIES
---------------
Customers not in countries listed above, please contact your local
distributor.
 
Readme.txt Sep 26, 2011, v.4.2.0.4
